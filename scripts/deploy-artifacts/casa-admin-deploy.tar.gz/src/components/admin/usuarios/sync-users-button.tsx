"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

// Dispara el extractor (folio_sync_casa_users) en la base. La función verifica
// por su cuenta que quien llama sea administrador, así que no hace falta
// duplicar esa comprobación acá.
export function SyncUsersButton({ lastSyncedAt }: { lastSyncedAt: string | null }) {
  const supabase = createClient();
  const router = useRouter();
  const [state, setState] = useState<"idle" | "syncing" | "done" | "error">("idle");
  const [message, setMessage] = useState("");

  async function sync() {
    setState("syncing");
    setMessage("");
    const { data, error } = await supabase.rpc("folio_sync_casa_users");
    if (error) {
      setState("error");
      setMessage(error.message);
      return;
    }
    setState("done");
    setMessage(`${data ?? 0} usuario(s) sincronizado(s).`);
    router.refresh();
  }

  return (
    <div className="flex flex-wrap items-center gap-3">
      <button
        onClick={sync}
        disabled={state === "syncing"}
        className="rounded-full bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-60"
      >
        {state === "syncing" ? "Sincronizando…" : "Sincronizar ahora"}
      </button>
      <span className="text-xs text-muted-foreground">
        {state === "error" && <span className="text-red-600">{message}</span>}
        {state === "done" && message}
        {state !== "error" && state !== "done" &&
          (lastSyncedAt
            ? `Última sincronización: ${new Date(lastSyncedAt).toLocaleString("es-PE")}`
            : "Nunca sincronizado.")}
      </span>
    </div>
  );
}
