import { createClient } from "@/lib/supabase/server";
import { PageShell } from "@/components/admin/page-shell";
import { SyncUsersButton } from "@/components/admin/usuarios/sync-users-button";

export const metadata = { title: "Usuarios y roles" };

interface FolioUser {
  user_id: string;
  email: string | null;
  display_name: string | null;
  folio_role: string | null;
  plan: string | null;
  account_status: string | null;
  apps: string[] | null;
  segment: string | null;
  engagement_score: number | null;
  interests: string[] | null;
  last_activity_at: string | null;
  metrics: Record<string, number> | null;
  synced_at: string | null;
}

const SEGMENT_STYLE: Record<string, string> = {
  comprometido: "bg-primary/10 text-primary",
  activo: "bg-emerald-500/10 text-emerald-700",
  nuevo: "bg-sky-500/10 text-sky-700",
  en_riesgo: "bg-amber-500/10 text-amber-700",
  inactivo: "bg-muted text-muted-foreground",
};

const SEGMENT_LABEL: Record<string, string> = {
  comprometido: "Comprometido",
  activo: "Activo",
  nuevo: "Nuevo",
  en_riesgo: "En riesgo",
  inactivo: "Inactivo",
};

function formatDate(value: string | null) {
  return value ? new Date(value).toLocaleDateString("es-PE") : "—";
}

export default async function UsuariosAdminPage() {
  const supabase = await createClient();
  const { data, error } = await supabase.rpc("folio_list_users", { p_limit: 200, p_offset: 0 });
  const users = (data as FolioUser[] | null) ?? [];

  const lastSyncedAt =
    users.map((u) => u.synced_at).filter(Boolean).sort().at(-1) ?? null;

  const counts = users.reduce<Record<string, number>>((acc, u) => {
    const key = u.segment ?? "sin_datos";
    acc[key] = (acc[key] ?? 0) + 1;
    return acc;
  }, {});

  return (
    <PageShell
      eyebrow="Cuenta"
      title="Usuarios y roles"
      description="Ficha unificada desde la base maestra: en qué apps está cada persona, su plan, y qué tan activa es en Casa de la Palabra."
    >
      <div className="space-y-6">
        <SyncUsersButton lastSyncedAt={lastSyncedAt} />

        {error && (
          <p className="rounded-2xl bg-red-50 p-4 text-sm text-red-600">
            No se pudo leer la base maestra: {error.message}
          </p>
        )}

        {users.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {Object.entries(counts).map(([segment, total]) => (
              <span
                key={segment}
                className={`rounded-full px-3 py-1 text-xs ${SEGMENT_STYLE[segment] ?? "bg-muted text-muted-foreground"}`}
              >
                {SEGMENT_LABEL[segment] ?? "Sin datos"}: {total}
              </span>
            ))}
          </div>
        )}

        <div className="overflow-x-auto rounded-2xl border border-border bg-card">
          <table className="w-full min-w-[880px] text-sm">
            <thead className="border-b border-border bg-muted/50 text-left text-xs uppercase text-muted-foreground">
              <tr>
                <th className="px-5 py-3">Persona</th>
                <th className="px-5 py-3">Segmento</th>
                <th className="px-5 py-3">Compromiso</th>
                <th className="px-5 py-3">Intereses</th>
                <th className="px-5 py-3">Apps</th>
                <th className="px-5 py-3">Plan</th>
                <th className="px-5 py-3">Última actividad</th>
              </tr>
            </thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.user_id} className="border-b border-border last:border-0">
                  <td className="px-5 py-3">
                    <div>{u.display_name ?? "—"}</div>
                    <div className="text-xs text-muted-foreground">{u.email ?? "—"}</div>
                  </td>
                  <td className="px-5 py-3">
                    <span
                      className={`rounded-full px-2.5 py-1 text-xs ${
                        SEGMENT_STYLE[u.segment ?? ""] ?? "bg-muted text-muted-foreground"
                      }`}
                    >
                      {SEGMENT_LABEL[u.segment ?? ""] ?? "Sin datos"}
                    </span>
                  </td>
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-2">
                      <div className="h-1.5 w-20 overflow-hidden rounded-full bg-muted">
                        <div
                          className="h-full rounded-full bg-primary"
                          style={{ width: `${u.engagement_score ?? 0}%` }}
                        />
                      </div>
                      <span className="text-xs text-muted-foreground">{u.engagement_score ?? 0}</span>
                    </div>
                    {u.metrics && (
                      <div className="mt-1 text-xs text-muted-foreground">
                        Racha {u.metrics.racha_actual ?? 0} d · {u.metrics.total_xp ?? 0} XP
                      </div>
                    )}
                  </td>
                  <td className="px-5 py-3 text-xs text-muted-foreground">
                    {u.interests?.length ? u.interests.join(", ") : "—"}
                  </td>
                  <td className="px-5 py-3 text-xs text-muted-foreground">
                    {u.apps?.length ? u.apps.join(", ") : "—"}
                  </td>
                  <td className="px-5 py-3 text-xs text-muted-foreground">
                    {u.plan ?? "—"}
                    {u.account_status && u.account_status !== "active" && ` (${u.account_status})`}
                  </td>
                  <td className="px-5 py-3 text-xs text-muted-foreground">{formatDate(u.last_activity_at)}</td>
                </tr>
              ))}
              {users.length === 0 && !error && (
                <tr>
                  <td colSpan={7} className="px-5 py-8 text-center text-muted-foreground">
                    Sin datos todavía. Pulsa «Sincronizar ahora» para extraer la actividad.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </PageShell>
  );
}
